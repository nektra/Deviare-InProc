/*
 * Copyright (C) 2010-2014 Nektra S.A., Buenos Aires, Argentina.
 * All rights reserved. Contact: http://www.nektra.com
 *
 *
 * This file is part of Deviare In-Proc
 *
 *
 * Commercial License Usage
 * ------------------------
 * Licensees holding valid commercial Deviare In-Proc licenses may use this
 * file in accordance with the commercial license agreement provided with the
 * Software or, alternatively, in accordance with the terms contained in
 * a written agreement between you and Nektra.  For licensing terms and
 * conditions see http://www.nektra.com/licensing/.  For further information
 * use the contact form at http://www.nektra.com/contact/.
 *
 *
 * GNU General Public License Usage
 * --------------------------------
 * Alternatively, this file may be used under the terms of the GNU
 * General Public License version 3.0 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.  Please review the following information to
 * ensure the GNU General Public License version 3.0 requirements will be
 * met: http://www.gnu.org/copyleft/gpl.html.
 *
 **/

#ifndef _NKT_NTAPI_H
#define _NKT_NTAPI_H

#include <windows.h>
#include <winternl.h>

namespace NktHooLib {

//-----------------------------------------------------------

#define NKT_HK_NT_SUCCESS(Status) (((NKT_HK_NTSTATUS)(Status)) >= 0)

#define NKT_HK_STATUS_SUCCESS                    0x00000000L
#define NKT_HK_STATUS_NOT_IMPLEMENTED            0xC0000002L
#define NKT_HK_STATUS_INFO_LENGTH_MISMATCH       0xC0000004L
#define NKT_HK_STATUS_BUFFER_TOO_SMALL           0xC0000023L
#define NKT_HK_STATUS_NOT_SUPPORTED              0xC00000BBL

#define NKT_HK_PROCESS_PLATFORM_X86                       1L
#define NKT_HK_PROCESS_PLATFORM_AMDX64                    2L

//-----------------------------------------------------------

typedef LONG NKT_HK_NTSTATUS;
typedef LONG NKT_HK_KPRIORITY;
typedef LONG NKT_HK_KWAIT_REASON;

typedef enum {
  MySystemProcessInformation = 5,
  MySystemSessionProcessInformation = 53,
  MySystemExtendedProcessInformation = 57
} NKT_HK_SYSTEM_INFORMATION_CLASS;

typedef enum {
  MyProcessBasicInformation = 0,
  MyProcessSessionInformation = 24,
  MyProcessWow64Information = 26
} NKT_HK_PROCESSINFOCLASS;

#pragma pack(8)
typedef struct {
  SIZE_T UniqueProcess;
  SIZE_T UniqueThread;
} NKT_HK_CLIENT_ID;

typedef struct {
  LARGE_INTEGER KernelTime;
  LARGE_INTEGER UserTime;
  LARGE_INTEGER CreateTime;
  ULONG WaitTime;
  PVOID StartAddress;
  NKT_HK_CLIENT_ID ClientId;
  NKT_HK_KPRIORITY Priority;
  LONG BasePriority;
  ULONG ContextSwitches;
  ULONG ThreadState;
  NKT_HK_KWAIT_REASON WaitReason;
} NKT_HK_SYSTEM_THREAD_INFORMATION, *LPNKT_HK_SYSTEM_THREAD_INFORMATION;

typedef struct {
  NKT_HK_SYSTEM_THREAD_INFORMATION ThreadInfo;
  PVOID StackBase;
  PVOID StackLimit;
  PVOID Win32StartAddress;
  PVOID TebAddress; //Vista or later
  ULONG Reserved1;
  ULONG Reserved2;
  ULONG Reserved3;
} NKT_HK_SYSTEM_EXTENDED_THREAD_INFORMATION, *LPNKT_HK_SYSTEM_EXTENDED_THREAD_INFORMATION;

typedef struct {
  USHORT Length;
  USHORT MaximumLength;
  LPWSTR Buffer;
} NKT_HK_UNICODE_STRING;

typedef struct {
  ULONG NextEntryOffset;
  ULONG NumberOfThreads;
  LARGE_INTEGER WorkingSetPrivateSize; //VISTA
  ULONG HardFaultCount; //WIN7
  ULONG NumberOfThreadsHighWatermark; //WIN7
  ULONGLONG CycleTime; //WIN7
  LARGE_INTEGER CreateTime;
  LARGE_INTEGER UserTime;
  LARGE_INTEGER KernelTime;
  NKT_HK_UNICODE_STRING ImageName;
  NKT_HK_KPRIORITY BasePriority;
  HANDLE UniqueProcessId;
  HANDLE InheritedFromUniqueProcessId;
  ULONG HandleCount;
  ULONG SessionId;
  ULONG_PTR PageDirectoryBase;
  //----
  SIZE_T PeakVirtualSize;
  SIZE_T VirtualSize;
  ULONG PageFaultCount;
  SIZE_T PeakWorkingSetSize;
  SIZE_T WorkingSetSize;
  SIZE_T QuotaPeakPagedPoolUsage;
  SIZE_T QuotaPagedPoolUsage;
  SIZE_T QuotaPeakNonPagedPoolUsage;
  SIZE_T QuotaNonPagedPoolUsage;
  SIZE_T PagefileUsage;
  SIZE_T PeakPagefileUsage;
  SIZE_T PrivatePageCount;
  //IO_COUNTERS
  LARGE_INTEGER ReadOperationCount;
  LARGE_INTEGER WriteOperationCount;
  LARGE_INTEGER OtherOperationCount;
  LARGE_INTEGER ReadTransferCount;
  LARGE_INTEGER WriteTransferCount;
  LARGE_INTEGER OtherTransferCount;
  union {
    NKT_HK_SYSTEM_THREAD_INFORMATION Threads[1];
    NKT_HK_SYSTEM_EXTENDED_THREAD_INFORMATION ExtThreads[1];
  };
} NKT_HK_SYSTEM_PROCESS_INFORMATION, *LPNKT_HK_SYSTEM_PROCESS_INFORMATION;

typedef struct {
  ULONG SessionId;
  ULONG SizeOfBuf;
  PVOID Buffer;
} NKT_HK_SYSTEM_SESSION_PROCESS_INFORMATION, *PNKT_HK_SYSTEM_SESSION_PROCESS_INFORMATION;

typedef struct {
  ULONG SessionId;
} NKT_HK_PROCESS_SESSION_INFORMATION, *LPNKT_HK_PROCESS_SESSION_INFORMATION;
#pragma pack()

//-----------------------------------------------------------

NKT_HK_NTSTATUS ntApi_NtSuspendThread(__in HANDLE hThread, __out_opt PULONG lpPrevSuspendCount);

NKT_HK_NTSTATUS ntApi_NtQuerySystemInformation(__in NKT_HK_SYSTEM_INFORMATION_CLASS nSysInfoClass, __inout PVOID lpSI,
                                               __in ULONG nSysInfoLength, __out_opt PULONG lpReturnLength);

NKT_HK_NTSTATUS ntApi_NtQueryInformationProcess(__in HANDLE hProcess, __in NKT_HK_PROCESSINFOCLASS nProcessInfoClass,
                                                __out_opt PVOID lpProcessInfo, __in ULONG nProcessInfoLength,
                                                __out_opt PULONG lpReturnLength);

VOID ntApi_GetNativeSysInfo(__out SYSTEM_INFO *lpSysInfo);

NKT_HK_NTSTATUS ntApi_GetProcessPlatformBits(__in HANDLE hProcess);

SIZE_T ntApi_ReadMem(__in HANDLE hProcess, __out LPVOID lpDest, __in LPVOID lpSrc, __in SIZE_T nBytesCount);
BOOL ntApi_WriteMem(__in HANDLE hProcess, __out LPVOID lpDest, __in LPVOID lpSrc, __in SIZE_T nBytesCount);

//-----------------------------------------------------------

} //NktHooLib

#endif //_NKT_NTAPI_H
