/*
 * Copyright (C) 2010-2014 Nektra S.A., Buenos Aires, Argentina.
 * All rights reserved. Contact: http://www.nektra.com
 *
 *
 * This file is part of Deviare In-Proc
 *
 *
 * Commercial License Usage
 * ------------------------
 * Licensees holding valid commercial Deviare In-Proc licenses may use this
 * file in accordance with the commercial license agreement provided with the
 * Software or, alternatively, in accordance with the terms contained in
 * a written agreement between you and Nektra.  For licensing terms and
 * conditions see http://www.nektra.com/licensing/.  For further information
 * use the contact form at http://www.nektra.com/contact/.
 *
 *
 * GNU General Public License Usage
 * --------------------------------
 * Alternatively, this file may be used under the terms of the GNU
 * General Public License version 3.0 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.  Please review the following information to
 * ensure the GNU General Public License version 3.0 requirements will be
 * met: http://www.gnu.org/copyleft/gpl.html.
 *
 **/

#include "amalgamation_defines.h"

#include "stdint.h"
#include "decode.h"
#include "extern.h"
#include "itab.h"
#include "syn.h"
#include "types.h"
#include "udint.h"

#include "decode.c"
#include "itab.c"

#define opr_cast    NktHookLib_ATT_opr_cast
#define gen_operand NktHookLib_ATT_gen_operand
#include "syn-att.c"
#undef opr_cast
#undef gen_operand

#define opr_cast NktHookLib_INTEL_opr_cast
#define gen_operand NktHookLib_INTEL_gen_operand
#include "syn-intel.c"
#undef opr_cast
#undef gen_operand

#include "syn.c"
#include "udis86.c"
