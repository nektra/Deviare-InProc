/*
 * Copyright (C) 2010-2014 Nektra S.A., Buenos Aires, Argentina.
 * All rights reserved. Contact: http://www.nektra.com
 *
 *
 * This file is part of Deviare In-Proc
 *
 *
 * Commercial License Usage
 * ------------------------
 * Licensees holding valid commercial Deviare In-Proc licenses may use this
 * file in accordance with the commercial license agreement provided with the
 * Software or, alternatively, in accordance with the terms contained in
 * a written agreement between you and Nektra.  For licensing terms and
 * conditions see http://www.nektra.com/licensing/.  For further information
 * use the contact form at http://www.nektra.com/contact/.
 *
 *
 * GNU General Public License Usage
 * --------------------------------
 * Alternatively, this file may be used under the terms of the GNU
 * General Public License version 3.0 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.  Please review the following information to
 * ensure the GNU General Public License version 3.0 requirements will be
 * met: http://www.gnu.org/copyleft/gpl.html.
 *
 **/

#include "NtApi.h"
#include "WaitableObjects.h"
#include <crtdbg.h>

namespace NktHooLib {

//-----------------------------------------------------------

#ifndef NKT_NK_STATUS_PARTIAL_COPY
  #define NKT_NK_STATUS_PARTIAL_COPY             0x8000000DL
#endif //!NKT_NK_STATUS_PARTIAL_COPY

//-----------------------------------------------------------

//ntdll
typedef void (NTAPI *lpfnNtSuspendThread)(__in HANDLE hThread, __out_opt PULONG PreviousSuspendCount);
typedef NKT_HK_NTSTATUS (NTAPI *lpfnNtQuerySystemInformation)(__in NKT_HK_SYSTEM_INFORMATION_CLASS sic,
                                                              __inout PVOID lpSI, __in ULONG nSysInfoLength,
                                                              __out_opt PULONG lpReturnLength);
typedef NKT_HK_NTSTATUS (NTAPI *lpfnNtQueryInformationProcess)(__in HANDLE hProcess,
                                              __in NKT_HK_PROCESSINFOCLASS nProcessInfoClass,
                                              __out_opt PVOID lpProcessInfo,
                                              __in ULONG nProcessInfoLength,
                                              __out_opt PULONG lpReturnLength);
typedef NKT_HK_NTSTATUS (NTAPI *lpfnNtReadVirtualMemory)(__in HANDLE hProcess, __in PVOID BaseAddress,
                                                         __out PVOID Buffer, __in SIZE_T NumberOfBytesToRead,
                                                         __out_opt PSIZE_T NumberOfBytesReaded);
typedef NKT_HK_NTSTATUS (NTAPI *lpfnNtWriteVirtualMemory)(__in HANDLE hProcess, __in PVOID BaseAddress,
                                                          __in PVOID Buffer, __in SIZE_T NumberOfBytesTloWrite,
                                                          __out_opt PSIZE_T NumberOfBytesWritten);
//kernel32
typedef BOOL (WINAPI *lpfnIsWow64Process)(__in HANDLE hProcess, __in PBOOL lpbIsWow64);
typedef VOID (WINAPI *lpfnGetNativeSystemInfo)(__out LPSYSTEM_INFO lpSystemInfo);
static SYSTEM_INFO sSysInfo = { 0 };

//-----------------------------------------------------------

static LONG volatile nInitialized = 0;
static LONG volatile nInitializedMutex = 0;
static HINSTANCE hNtDll = NULL;
static lpfnNtSuspendThread fnNtSuspendThread = NULL;
static lpfnNtQuerySystemInformation fnNtQuerySystemInformation = NULL;
static lpfnNtQueryInformationProcess fnNtQueryInformationProcess = NULL;
static lpfnNtReadVirtualMemory fnNtReadVirtualMemory = NULL;
static lpfnNtWriteVirtualMemory fnNtWriteVirtualMemory = NULL;
static HINSTANCE hKernel32Dll = NULL;
static lpfnIsWow64Process fnIsWow64Process = NULL;
static lpfnGetNativeSystemInfo fnGetNativeSystemInfo = NULL;

//-----------------------------------------------------------

static VOID Initialize();
static SIZE_T tryMemCopy(__out void *lpDest, __in const void *lpSrc, __in SIZE_T nCount);

//-----------------------------------------------------------

NKT_HK_NTSTATUS ntApi_NtSuspendThread(__in HANDLE hThread, __out_opt PULONG lpPrevSuspendCount)
{
  if (lpPrevSuspendCount != NULL)
    *lpPrevSuspendCount = 0;
  if (nInitialized == 0)
    Initialize();
  if (fnNtSuspendThread == NULL)
    return NKT_HK_STATUS_NOT_IMPLEMENTED;
  fnNtSuspendThread(hThread, lpPrevSuspendCount);
  return NKT_HK_STATUS_SUCCESS;
}

NKT_HK_NTSTATUS ntApi_NtQuerySystemInformation(__in NKT_HK_SYSTEM_INFORMATION_CLASS nSysInfoClass, __inout PVOID lpSI,
                                               __in ULONG nSysInfoLength, __out_opt PULONG lpReturnLength)
{
  if (lpReturnLength != NULL)
    *lpReturnLength = 0;
  if (nInitialized == 0)
    Initialize();
  if (fnNtQuerySystemInformation == NULL)
    return NKT_HK_STATUS_NOT_IMPLEMENTED;
  return fnNtQuerySystemInformation(nSysInfoClass, lpSI, nSysInfoLength, lpReturnLength);
}

NKT_HK_NTSTATUS ntApi_NtQueryInformationProcess(__in HANDLE hProcess, __in NKT_HK_PROCESSINFOCLASS nProcessInfoClass,
                                                __out_opt PVOID lpProcessInfo, __in ULONG nProcessInfoLength,
                                                __out_opt PULONG lpReturnLength)
{
  if (lpReturnLength != NULL)
    *lpReturnLength = 0;
  if (nInitialized == 0)
    Initialize();
  if (fnNtQueryInformationProcess == NULL)
    return NKT_HK_STATUS_NOT_IMPLEMENTED;
  return fnNtQueryInformationProcess(hProcess, nProcessInfoClass, lpProcessInfo,
                                     nProcessInfoLength, lpReturnLength);
}

VOID ntApi_GetNativeSysInfo(__out SYSTEM_INFO *lpSysInfo)
{
  if (nInitialized == 0)
    Initialize();
  if (lpSysInfo != NULL)
    memcpy(lpSysInfo, &sSysInfo, sizeof(sSysInfo));
  return;
}

NKT_HK_NTSTATUS ntApi_GetProcessPlatformBits(__in HANDLE hProcess)
{
  BOOL bIsWow64;

  if (nInitialized == 0)
    Initialize();
  if (fnIsWow64Process == NULL)
    return NKT_HK_STATUS_NOT_IMPLEMENTED;
  switch (sSysInfo.wProcessorArchitecture)
  {
    case PROCESSOR_ARCHITECTURE_INTEL:
      return NKT_HK_PROCESS_PLATFORM_X86;

    case PROCESSOR_ARCHITECTURE_AMD64:
      //check on 64-bit platforms
      if (fnIsWow64Process != NULL && fnIsWow64Process(hProcess, &bIsWow64) != FALSE)
      {
#if defined _M_IX86
        return (bIsWow64 == FALSE) ? NKT_HK_PROCESS_PLATFORM_AMDX64 : NKT_HK_PROCESS_PLATFORM_X86;
#elif defined _M_X64
        return (bIsWow64 != FALSE) ? NKT_HK_PROCESS_PLATFORM_X86 : NKT_HK_PROCESS_PLATFORM_AMDX64;
#endif
      }
#if defined _M_IX86
      return NKT_HK_PROCESS_PLATFORM_X86;
#elif defined _M_X64
      return NKT_HK_PROCESS_PLATFORM_AMDX64;
#endif
      break;
    //case PROCESSOR_ARCHITECTURE_IA64:
    //case PROCESSOR_ARCHITECTURE_ALPHA64:
  }
  return NKT_HK_STATUS_NOT_SUPPORTED;
}

SIZE_T ntApi_ReadMem(__in HANDLE hProcess, __in LPVOID lpDest, __in LPVOID lpSrc, __in SIZE_T nBytesCount)
{
  NKT_HK_NTSTATUS nStatus;
  SIZE_T nReaded;

  if (nBytesCount == 0)
    return 0;
  if (hProcess == ::GetCurrentProcess())
    return tryMemCopy(lpDest, lpSrc, nBytesCount);
  if (nInitialized == 0)
    Initialize();
  if (fnNtReadVirtualMemory == NULL)
    return 0;
  nStatus = fnNtReadVirtualMemory(hProcess, lpSrc, lpDest, nBytesCount, &nReaded);
  if (nStatus == NKT_NK_STATUS_PARTIAL_COPY)
    return nReaded;
  return (NKT_HK_NT_SUCCESS(nStatus)) ? nBytesCount : 0;
}

BOOL ntApi_WriteMem(__in HANDLE hProcess, __in LPVOID lpDest, __in LPVOID lpSrc, __in SIZE_T nBytesCount)
{
  NKT_HK_NTSTATUS nStatus;
  SIZE_T nWritten;

  if (nBytesCount == 0)
    return TRUE;
  if (hProcess == ::GetCurrentProcess())
    return (tryMemCopy(lpDest, lpSrc, nBytesCount) == nBytesCount) ? TRUE : FALSE;
  if (nInitialized == 0)
    Initialize();
  if (fnNtWriteVirtualMemory == NULL)
    return FALSE;
  nStatus = fnNtWriteVirtualMemory(hProcess, lpDest, lpSrc, nBytesCount, &nWritten);
  return (NKT_HK_NT_SUCCESS(nStatus) ||
          (nStatus == NKT_NK_STATUS_PARTIAL_COPY && nWritten == nBytesCount)) ? TRUE : FALSE;
}

//-----------------------------------------------------------

static VOID Initialize()
{
  CNktSimpleLockNonReentrant cLock(&nInitializedMutex);

  if (nInitialized == 0)
  {
    hNtDll = ::GetModuleHandleW(L"ntdll.dll");
    if (hNtDll != NULL)
    {
      fnNtSuspendThread = (lpfnNtSuspendThread)::GetProcAddress(hNtDll, "NtSuspendThread");
      fnNtQuerySystemInformation = (lpfnNtQuerySystemInformation)::GetProcAddress(hNtDll, "NtQuerySystemInformation");
      fnNtQueryInformationProcess = (lpfnNtQueryInformationProcess)::GetProcAddress(hNtDll, "NtQueryInformationProcess");
      fnNtReadVirtualMemory = (lpfnNtReadVirtualMemory)::GetProcAddress(hNtDll, "NtReadVirtualMemory");
      fnNtWriteVirtualMemory = (lpfnNtWriteVirtualMemory)::GetProcAddress(hNtDll, "NtWriteVirtualMemory");
    }
    //----
    hKernel32Dll = ::LoadLibraryW(L"kernel32.dll");
    if (hKernel32Dll != NULL)
    {
      fnIsWow64Process = (lpfnIsWow64Process)::GetProcAddress(hKernel32Dll, "IsWow64Process");
      fnGetNativeSystemInfo = (lpfnGetNativeSystemInfo)::GetProcAddress(hKernel32Dll, "GetNativeSystemInfo");
    }
    //----
    if (sSysInfo.wProcessorArchitecture == 0)
    {
      if (fnGetNativeSystemInfo != NULL)
        fnGetNativeSystemInfo(&sSysInfo);
      else
        ::GetSystemInfo(&sSysInfo);
    }
    //----
    NktInterlockedExchange(&nInitialized, 1);
  }
  return;
}

//-----------------------------------------------------------

#define XISALIGNED(x)  ((((SIZE_T)(x)) & (sizeof(SIZE_T)-1)) == 0)
static SIZE_T tryMemCopy(__out void *lpDest, __in const void *lpSrc, __in SIZE_T nCount)
{
  LPBYTE s, d;
  SIZE_T nOrigCount;

  s = (LPBYTE)lpSrc;
  d = (LPBYTE)lpDest;
  nOrigCount = nCount;
  try
  {
    if (XISALIGNED(s) && XISALIGNED(d))
    {
      while (nCount >= sizeof(SIZE_T))
      {
        *((SIZE_T*)d) = *((SIZE_T*)s);
        s += sizeof(SIZE_T);
        d += sizeof(SIZE_T);
        nCount -= sizeof(SIZE_T);
      }
    }
  }
  catch (...)
  { }
  try
  {
    while (nCount > 0)
    {
      *d++ = *s++;
      nCount--;
    }
  }
  catch (...)
  { }
  return nOrigCount-nCount;
}
#undef XISALIGNED

} //NktHooLib
