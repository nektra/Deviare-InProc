/*
 * Copyright (C) 2010-2014 Nektra S.A., Buenos Aires, Argentina.
 * All rights reserved. Contact: http://www.nektra.com
 *
 *
 * This file is part of Deviare In-Proc
 *
 *
 * Commercial License Usage
 * ------------------------
 * Licensees holding valid commercial Deviare In-Proc licenses may use this
 * file in accordance with the commercial license agreement provided with the
 * Software or, alternatively, in accordance with the terms contained in
 * a written agreement between you and Nektra.  For licensing terms and
 * conditions see http://www.nektra.com/licensing/.  For further information
 * use the contact form at http://www.nektra.com/contact/.
 *
 *
 * GNU General Public License Usage
 * --------------------------------
 * Alternatively, this file may be used under the terms of the GNU
 * General Public License version 3.0 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.  Please review the following information to
 * ensure the GNU General Public License version 3.0 requirements will be
 * met: http://www.gnu.org/copyleft/gpl.html.
 *
 **/

#include "ThreadSuspend.h"
#include "NtApi.h"
#include "ProcessEntry.h"
#include <crtdbg.h>

namespace NktHooLib {

//-----------------------------------------------------------

#define X_ALLOCATION_SIZE                                256
#define X_CHECKTHREADS_ALLOCATION_SIZE                 65536

//-----------------------------------------------------------

#define NEXT_PROCESS(_currProc)                            \
          (LPNKT_HK_SYSTEM_PROCESS_INFORMATION)((LPBYTE)_currProc +(SIZE_T)(_currProc->NextEntryOffset))

//-----------------------------------------------------------

static const NKT_HK_SYSTEM_INFORMATION_CLASS aGatherMethods[3] = {
  MySystemProcessInformation, MySystemSessionProcessInformation, MySystemExtendedProcessInformation
};

//-----------------------------------------------------------

CNktThreadSuspend::CNktThreadSuspend()
{
  memset(&sSuspendedTids, 0, sizeof(sSuspendedTids));
  //NOTE: A deadlock may arise in the second call to EnumProcesses (the one that checks if new threads
  //      where created while suspending) if a suspended thread was in the middle of a memory allocation
  //      routine (malloc, etc.). So we use a special memory handling in this class.
  memset(&sCheckThreads, 0, sizeof(sCheckThreads));
  return;
}

CNktThreadSuspend::~CNktThreadSuspend()
{
  ResumeAll();
  //----
  if (sCheckThreads.lpMem != NULL)
    free(sCheckThreads.lpMem);
  return;
}

DWORD CNktThreadSuspend::SuspendAll(__in DWORD dwPid, __in IP_RANGE *lpRanges, __in SIZE_T nRangesCount)
{
  CONTEXT sThreadCtx;
  DWORD dwCurrTid, dwCurrSessionId;
  HANDLE hThread, hProcess;
  SIZE_T i, k, nSuspendTries, nCurrIP, nEnumMethod;
  BOOL bGrowCheckProcessThreadsMem;
  DWORD dwOsErr;
  SYSTEM_INFO sSi;
  int nOrigPriority;

  hProcess = CProcessesHandles::CreateHandle(dwPid, PROCESS_SUSPEND_RESUME|PROCESS_QUERY_INFORMATION);
  if (hProcess == NULL)
    return ERROR_ACCESS_DENIED;
  ntApi_GetNativeSysInfo(&sSi);
  bGrowCheckProcessThreadsMem = (sCheckThreads.nSize == 0) ? TRUE : FALSE;
  dwCurrTid = ::GetCurrentThreadId();
  nOrigPriority = ::GetThreadPriority(::GetCurrentThread());
  ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
  //main loop
  for (;;)
  {
    if (bGrowCheckProcessThreadsMem != FALSE)
    {
      if (GrowCheckProcessThreadsMem() == FALSE)
      {
        ::CloseHandle(hProcess);
        return ERROR_NOT_ENOUGH_MEMORY;
      }
      bGrowCheckProcessThreadsMem = FALSE;
    }
    //----
    dwOsErr = EnumProcessThreads(dwPid, hProcess, &nEnumMethod, &dwCurrSessionId);
    if (dwOsErr != NO_ERROR)
      break;
    //suspend all threads in the list
    for (i=0; i<sSuspendedTids.nCount; i++)
    {
      if (sSuspendedTids.lpList[i].dwTid == dwCurrTid)
        continue; //skip myself
      //open thread for context and suspend
      hThread = sSuspendedTids.lpList[i].hThread = ::OpenThread(THREAD_GET_CONTEXT|THREAD_SUSPEND_RESUME,
                                                                FALSE, sSuspendedTids.lpList[i].dwTid);
      if (hThread != NULL)
      {
        //suspend the thread
        for (nSuspendTries=20; nSuspendTries>0; nSuspendTries--)
        {
          if (ntApi_NtSuspendThread(hThread, NULL) == NKT_HK_STATUS_NOT_IMPLEMENTED)
            ::SuspendThread(hThread);
          //check thread position until it leaves our segment
          memset(&sThreadCtx, 0, sizeof(sThreadCtx));
          sThreadCtx.ContextFlags = CONTEXT_FULL;
          if (::GetThreadContext(hThread, &sThreadCtx) == FALSE)
            break;
#if defined _M_X64
          nCurrIP = (SIZE_T)sThreadCtx.Rip;
#else //_M_X64
          nCurrIP = (SIZE_T)sThreadCtx.Eip;
#endif //_M_X64
          sSuspendedTids.lpList[i].nCurrIP = nCurrIP;
          for (k=0; k<nRangesCount; k++)
          {
            if (nCurrIP >= lpRanges[k].nStart && nCurrIP < lpRanges[k].nEnd)
              break;
          }
          if (k >= nRangesCount)
            break; //not in our range => exit loop
          //resume thread, sleep a moment and try again
          ::ResumeThread(hThread);
          ::Sleep(1);
        }
        if (nSuspendTries == 0)
          break; //may this thread is waiting for something in another thread
      }
    }
    if (i < sSuspendedTids.nCount)
    {
      //could not send to sleep, all threads, wait a little time and try again
      dwOsErr = ERROR_NOT_READY;
      goto sa_retry;
    }
    //SuspendThread suspends the threads when leaving kernel mode by executing an APC
    //In WOW64, when the thread exits kernel mode, it usually jumps to code in wow64###.dll, which is
    //user-mode but some internal locks may be held by that dll's
    //The problem is that "NtQuerySystemInformation" may deadlock if called on this situation so,
    //although unsafe, we must skip the "detect recently new thread created code" below
    if (sSi.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64 ||
        sSi.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_IA64 ||
        sSi.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_ALPHA64)
    {
      if (ntApi_GetProcessPlatformBits(hProcess) == 32)
        break; //process is running on Wow64... skip check
    }
    //if we are here, we must confirm that no new threads where created in the middle
    //of the process' suspension
    dwOsErr = CheckProcessThreads(dwPid, nEnumMethod, dwCurrSessionId);
    if (dwOsErr == NO_ERROR)
      break;
    if (dwOsErr == ERROR_ACCESS_DENIED)
    {
      ResumeAll();
      break;
    }
    //if threads count mismatch or no memory, retry
    _ASSERT(dwOsErr == ERROR_NOT_READY || dwOsErr == ERROR_NOT_ENOUGH_MEMORY);
sa_retry:
    ResumeAll();
    ::SetThreadPriority(::GetCurrentThread(), nOrigPriority);
    ::Sleep(10); //sleep for a moment
    ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
    //----
    if (dwOsErr == ERROR_NOT_ENOUGH_MEMORY)
      bGrowCheckProcessThreadsMem = TRUE;
  }
  ::SetThreadPriority(::GetCurrentThread(), nOrigPriority);
  ::CloseHandle(hProcess);
  return dwOsErr;
}

VOID CNktThreadSuspend::ResumeAll()
{
  SIZE_T i;

  if (sSuspendedTids.lpList != NULL)
  {
    for (i=0; i<sSuspendedTids.nCount; i++)
    {
      if (sSuspendedTids.lpList[i].hThread != NULL)
      {
        ::ResumeThread(sSuspendedTids.lpList[i].hThread);
        ::CloseHandle(sSuspendedTids.lpList[i].hThread);
      }
    }
    free(sSuspendedTids.lpList);
    sSuspendedTids.lpList = NULL;
  }
  sSuspendedTids.nCount = 0;
  return;
}

BOOL CNktThreadSuspend::CheckIfThreadIsInRange(__in SIZE_T nStart, __in SIZE_T nEnd)
{
  SIZE_T i;

  if (sSuspendedTids.lpList != NULL)
  {
    for (i=0; i<sSuspendedTids.nCount; i++)
    {
      if (sSuspendedTids.lpList[i].hThread != NULL &&
        sSuspendedTids.lpList[i].nCurrIP >= nStart &&
        sSuspendedTids.lpList[i].nCurrIP < nEnd)
        return TRUE;
    }
  }
  return FALSE;
}

DWORD CNktThreadSuspend::EnumProcessThreads(__in DWORD dwPid, __in HANDLE hProcess, __out SIZE_T *lpnEnumMethod,
                                            __out LPDWORD lpdwSessionId)
{
  SIZE_T nRealSize;
  LPNKT_HK_SYSTEM_PROCESS_INFORMATION lpSysProcInfo, lpCurrProc;
  NKT_HK_SYSTEM_SESSION_PROCESS_INFORMATION sSpi;
  ULONG k, kNeeded, nSysProcInfoLen;
  PVOID lpPtr;
  NKT_HK_NTSTATUS nNtStatus;

  _ASSERT(lpnEnumMethod != NULL && lpdwSessionId != NULL);
  sSuspendedTids.lpList = NULL;
  sSuspendedTids.nCount = 0;
  nRealSize = 0;
  //gather information using three methods
  for ((*lpnEnumMethod)=0; (*lpnEnumMethod)<3; (*lpnEnumMethod)++)
  {
    if ((*lpnEnumMethod) == 1)
    {
      if (GetProcessSessionId(hProcess, lpdwSessionId) == FALSE)
        continue; //skip this method if cannot get session id
      sSpi.SessionId = *lpdwSessionId;
    }
    nSysProcInfoLen = 128000;
    _ASSERT(nSysProcInfoLen >= sizeof(NKT_HK_SYSTEM_PROCESS_INFORMATION));
    for (;;)
    {
      lpSysProcInfo = (LPNKT_HK_SYSTEM_PROCESS_INFORMATION)malloc(nSysProcInfoLen);
      if (lpSysProcInfo == NULL)
        return ERROR_NOT_ENOUGH_MEMORY;
      switch (*lpnEnumMethod)
      {
        case 1:
          sSpi.SizeOfBuf = nSysProcInfoLen;
          sSpi.Buffer = lpSysProcInfo;
          k = (ULONG)sizeof(sSpi);
          lpPtr = &sSpi;
          break;
        default:
          lpPtr = lpSysProcInfo;
          k = nSysProcInfoLen;
          break;
      }
      kNeeded = 0; //NtQuerySystemInformation seems dislike using the same var for needed and input size
      nNtStatus = ntApi_NtQuerySystemInformation(aGatherMethods[*lpnEnumMethod], lpPtr, k, &kNeeded);
      if (NKT_HK_NT_SUCCESS(nNtStatus))
        break;
      if (nNtStatus != NKT_HK_STATUS_INFO_LENGTH_MISMATCH && nNtStatus != NKT_HK_STATUS_BUFFER_TOO_SMALL)
      {
        free(lpSysProcInfo);
        return ERROR_ACCESS_DENIED;
      }
      if (kNeeded == 0)
      {
        //ThinApp may return STATUS_INFO_LENGTH_MISMATCH and needed equal to 0!!!!
        memset(lpSysProcInfo, 0, sizeof(NKT_HK_SYSTEM_PROCESS_INFORMATION));
        break;
      }
      kNeeded += 4096; //check if buffer small error and needed size less than provided (should not happen)
      if (kNeeded < nSysProcInfoLen)
        kNeeded = nSysProcInfoLen+4096;
      nSysProcInfoLen = kNeeded;
      free(lpSysProcInfo); //mem-leak fix by tkoecker
    }
    //find the target process
    lpCurrProc = lpSysProcInfo;
    while (lpCurrProc != NULL && (DWORD)(lpCurrProc->UniqueProcessId) != dwPid)
    {
      lpCurrProc = (lpCurrProc->NextEntryOffset != 0) ? NEXT_PROCESS(lpCurrProc) : NULL;
    }
    if (lpCurrProc != NULL)
      break;
  }
  //current process not found (?), may be, for e.g., ThinApp hooking apis
  if (lpCurrProc == NULL)
  {
    free(lpSysProcInfo);
    return ERROR_ACCESS_DENIED;
  }
  if (lpCurrProc->NumberOfThreads > 0)
  {
    sSuspendedTids.nCount = (SIZE_T)(lpCurrProc->NumberOfThreads);
    sSuspendedTids.lpList = (LPTHREAD_ITEM)malloc(sSuspendedTids.nCount * sizeof(THREAD_ITEM));
    if (sSuspendedTids.lpList == NULL)
    {
      free(lpSysProcInfo);
      return ERROR_NOT_ENOUGH_MEMORY;
    }
    //scan the threads of the process
    if ((*lpnEnumMethod) != 2)
    {
      for (k=0; k<lpCurrProc->NumberOfThreads; k++)
      {
        sSuspendedTids.lpList[k].dwTid = (DWORD)(lpCurrProc->Threads[k].ClientId.UniqueThread);
        sSuspendedTids.lpList[k].hThread = NULL;
      }
    }
    else
    {
      for (k=0; k<lpCurrProc->NumberOfThreads; k++)
      {
        sSuspendedTids.lpList[k].dwTid = (DWORD)(lpCurrProc->ExtThreads[k].ThreadInfo.ClientId.UniqueThread);
        sSuspendedTids.lpList[k].hThread = NULL;
      }
    }
  }
  free(lpSysProcInfo);
  return NO_ERROR;
}

BOOL CNktThreadSuspend::GrowCheckProcessThreadsMem()
{
  LPBYTE lpPtr;

  lpPtr = (LPBYTE)malloc(sCheckThreads.nSize + X_CHECKTHREADS_ALLOCATION_SIZE);
  if (lpPtr == NULL)
    return FALSE;
  if (sCheckThreads.lpMem != NULL)
    free(sCheckThreads.lpMem);
  sCheckThreads.lpMem = lpPtr;
  sCheckThreads.nSize += X_CHECKTHREADS_ALLOCATION_SIZE;
  return TRUE;
}

DWORD CNktThreadSuspend::CheckProcessThreads(__in DWORD dwPid, __in SIZE_T nEnumMethod, __in DWORD dwSessionId)
{
  LPNKT_HK_SYSTEM_PROCESS_INFORMATION lpSysProcInfo, lpCurrProc;
  NKT_HK_SYSTEM_SESSION_PROCESS_INFORMATION sSpi;
  SIZE_T i;
  ULONG k, kNeeded;
  PVOID lpPtr;
  NKT_HK_NTSTATUS nNtStatus;

  _ASSERT(nEnumMethod >= 0 && nEnumMethod <= 2);
  //gather information
  lpSysProcInfo = (LPNKT_HK_SYSTEM_PROCESS_INFORMATION)(sCheckThreads.lpMem);
  _ASSERT(lpSysProcInfo != NULL);
  _ASSERT(sCheckThreads.nSize != 0);
  switch (nEnumMethod)
  {
    case 1:
      sSpi.SessionId = dwSessionId;
      sSpi.SizeOfBuf = (ULONG)(sCheckThreads.nSize);
      sSpi.Buffer = lpSysProcInfo;
      k = (ULONG)sizeof(sSpi);
      lpPtr = &sSpi;
      break;
    default:
      lpPtr = lpSysProcInfo;
      k = (ULONG)(sCheckThreads.nSize);
      break;
  }
  kNeeded = 0; //NtQuerySystemInformation seems dislike using the same var for needed and input size
  nNtStatus = ntApi_NtQuerySystemInformation(aGatherMethods[nEnumMethod], lpPtr, k, &kNeeded);
  if (!NKT_HK_NT_SUCCESS(nNtStatus))
  {
    switch (nNtStatus)
    {
      case NKT_HK_STATUS_NOT_IMPLEMENTED:
        return ERROR_CALL_NOT_IMPLEMENTED;
      case NKT_HK_STATUS_INFO_LENGTH_MISMATCH:
      case NKT_HK_STATUS_BUFFER_TOO_SMALL:
        return ERROR_NOT_ENOUGH_MEMORY;
    }
    return ERROR_ACCESS_DENIED;
  }
  //find the current process
  lpCurrProc = lpSysProcInfo;
  while (lpCurrProc != NULL && (DWORD)(lpCurrProc->UniqueProcessId) != dwPid)
  {
    lpCurrProc = (lpCurrProc->NextEntryOffset != 0) ? NEXT_PROCESS(lpCurrProc) : NULL;
  }
  //current process not found (?) grrrr
  if (lpCurrProc == NULL)
    return ERROR_ACCESS_DENIED;
  if (sSuspendedTids.nCount != (SIZE_T)(lpCurrProc->NumberOfThreads))
    return ERROR_NOT_READY;
  for (i=0; i<sSuspendedTids.nCount; i++)
  {
    if (nEnumMethod != 2)
    {
      for (k=0; k<lpCurrProc->NumberOfThreads; k++)
      {
        if (sSuspendedTids.lpList[i].dwTid == (DWORD)(lpCurrProc->Threads[k].ClientId.UniqueThread))
          break;
      }
    }
    else
    {
      for (k=0; k<lpCurrProc->NumberOfThreads; k++)
      {
        if (sSuspendedTids.lpList[i].dwTid == (DWORD)(lpCurrProc->ExtThreads[k].ThreadInfo.ClientId.UniqueThread))
          break;
      }
    }
    if (k >= lpCurrProc->NumberOfThreads)
      return ERROR_NOT_READY;
  }
  //done
  return NO_ERROR;
}

BOOL CNktThreadSuspend::GetProcessSessionId(__in HANDLE hProcess, __out LPDWORD lpdwSessionId)
{
  NKT_HK_PROCESS_SESSION_INFORMATION sSi;
  NKT_HK_NTSTATUS nNtStatus;
  ULONG k;

  _ASSERT(lpdwSessionId != NULL);
  k = 0;
  nNtStatus = ntApi_NtQueryInformationProcess(hProcess, MyProcessSessionInformation, &sSi, (ULONG)sizeof(sSi), &k);
  if (NKT_HK_NT_SUCCESS(nNtStatus))
  {
    *lpdwSessionId = sSi.SessionId;
    return TRUE;
  }
  return FALSE;
}

} //NktHooLib
