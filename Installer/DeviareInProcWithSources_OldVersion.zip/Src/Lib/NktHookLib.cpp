/*
 * Copyright (C) 2010-2014 Nektra S.A., Buenos Aires, Argentina.
 * All rights reserved. Contact: http://www.nektra.com
 *
 *
 * This file is part of Deviare In-Proc
 *
 *
 * Commercial License Usage
 * ------------------------
 * Licensees holding valid commercial Deviare In-Proc licenses may use this
 * file in accordance with the commercial license agreement provided with the
 * Software or, alternatively, in accordance with the terms contained in
 * a written agreement between you and Nektra.  For licensing terms and
 * conditions see http://www.nektra.com/licensing/.  For further information
 * use the contact form at http://www.nektra.com/contact/.
 *
 *
 * GNU General Public License Usage
 * --------------------------------
 * Alternatively, this file may be used under the terms of the GNU
 * General Public License version 3.0 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.  Please review the following information to
 * ensure the GNU General Public License version 3.0 requirements will be
 * met: http://www.gnu.org/copyleft/gpl.html.
 *
 **/

#include "..\..\Include\NktHookLib.h"
#include "libudis86\GetInstructionLength.h"
#include "LinkedList.h"
#include "WaitableObjects.h"
#include "NtApi.h"
#include "ThreadSuspend.h"
#include "HookEntry.h"
#include <crtdbg.h>

//-----------------------------------------------------------

#define MAX_SUSPEND_IPRANGES                              10

#define X_ARRAYLEN(x)               (sizeof(x)/sizeof(x[0]))

//-----------------------------------------------------------

static DWORD GetProcessIdFromHandle(__in HANDLE hProc);

//-----------------------------------------------------------

namespace NktHooLib {

class CInternals
{
public:
  CInternals()
    {
    sOptions.bSuspendThreads = TRUE;
#ifdef _DEBUG
    sOptions.bOutputDebug = TRUE;
#else _DEBUG
    sOptions.bOutputDebug = FALSE;
#endif //_DEBUG
    return;
    };

private:
  friend class CNktHookLib;

  TNktLnkLst<CHookEntry> cHooksList;
  CNktThreadSuspend cThreadSuspender;
  CNktFastMutex cMtx;
  CProcessesHandles cProcHdrMgr;
  struct {
    BOOL bSuspendThreads;
    BOOL bOutputDebug;
    BOOL bSkipJumps;
  } sOptions;
};

} //NktHooLib

#define int_data           ((NktHooLib::CInternals*)lpInternals)

//-----------------------------------------------------------

CNktHookLib::CNktHookLib()
{
  lpInternals = new NktHooLib::CInternals();
  return;
}

CNktHookLib::~CNktHookLib()
{
  if (lpInternals != NULL)
  {
    UnhookAll();
    delete int_data;
    lpInternals = NULL;
  }
  return;
}

DWORD CNktHookLib::Hook(__out SIZE_T *lpnHookId, __out LPVOID *lplpCallOriginal, __in LPVOID lpProcToHook,
                        __in LPVOID lpNewProcAddr, __in DWORD dwFlags)
{
  return RemoteHook(lpnHookId, lplpCallOriginal, ::GetCurrentProcessId(), lpProcToHook, lpNewProcAddr, dwFlags);
}

DWORD CNktHookLib::Hook(__inout HOOK_INFO aHookInfo[], __in SIZE_T nCount, __in DWORD dwFlags)
{
  return RemoteHook(aHookInfo, nCount, ::GetCurrentProcessId(), dwFlags);
}

DWORD CNktHookLib::RemoteHook(__out SIZE_T *lpnHookId, __out LPVOID *lplpCallOriginal, __in DWORD dwPid,
                              __in LPVOID lpProcToHook, __in LPVOID lpNewProcAddr, __in DWORD dwFlags)
{
  HOOK_INFO sHook;
  DWORD dwOsErr;

  if (lpnHookId != NULL)
    *lpnHookId = 0;
  if (lplpCallOriginal != NULL)
    *lplpCallOriginal = NULL;
  if (lpnHookId == NULL || lplpCallOriginal == NULL)
    return ERROR_INVALID_PARAMETER;
  sHook.lpProcToHook = lpProcToHook;
  sHook.lpNewProcAddr = lpNewProcAddr;
  dwOsErr = RemoteHook(&sHook, 1, dwPid, dwFlags);
  if (dwOsErr == NO_ERROR)
  {
    *lpnHookId = sHook.nHookId;
    *lplpCallOriginal = sHook.lpCallOriginal;
  }
  return dwOsErr;
}

DWORD CNktHookLib::RemoteHook(__inout HOOK_INFO aHookInfo[], __in SIZE_T nCount, __in DWORD dwPid, __in DWORD dwFlags)
{
  DWORD dwOsErr;

  if (dwPid == 0)
    return ERROR_INVALID_PARAMETER;
  if (lpInternals != NULL)
  {
    NktHooLib::CNktAutoFastMutex cAutoLock(&(int_data->cMtx));
    NktHooLib::CProcessesHandles::CEntryPtr cProcEntry;
    NktHooLib::CHookEntry *lpHookEntry, **lpNewEntriesList;
    BYTE aNewCode[0x80 + HOOKENG_MAX_STUB_SIZE];
    SIZE_T nHookIdx;

    if (aHookInfo == 0 || nCount == 0)
      return ERROR_INVALID_PARAMETER;
    for (nHookIdx=0; nHookIdx<nCount; nHookIdx++)
    {
      if (aHookInfo[nHookIdx].lpProcToHook == NULL ||
          aHookInfo[nHookIdx].lpNewProcAddr == NULL)
        return ERROR_INVALID_PARAMETER;
      aHookInfo[nHookIdx].nHookId = 0;
      aHookInfo[nHookIdx].lpCallOriginal = NULL;
    }
    if ((::GetVersion() & 0x80000000) != 0)
      return ERROR_CALL_NOT_IMPLEMENTED; //reject win9x
    //get process handle
    if (dwPid != ::GetCurrentProcessId())
    {
      cProcEntry.Attach(int_data->cProcHdrMgr.Get(dwPid));
      if (cProcEntry == NULL)
        return ::GetLastError();
    }
    //create entries for each item
    lpNewEntriesList = (NktHooLib::CHookEntry**)malloc(nCount*sizeof(NktHooLib::CHookEntry*));
    if (lpNewEntriesList != NULL)
    {
      dwOsErr = NO_ERROR;
      memset(lpNewEntriesList, 0, nCount * sizeof(NktHooLib::CHookEntry*));
    }
    else
    {
      dwOsErr = ERROR_NOT_ENOUGH_MEMORY;
    }
    for (nHookIdx=0; nHookIdx<nCount && dwOsErr==NO_ERROR; nHookIdx++)
    {
      DWORD dw;

      //allocate new entry
      lpHookEntry = new NktHooLib::CHookEntry(cProcEntry);
      if (lpHookEntry == NULL)
      {
        dwOsErr = ERROR_NOT_ENOUGH_MEMORY;
        continue;
      }
      lpNewEntriesList[nHookIdx] = lpHookEntry;
      lpHookEntry->lpOrigProc = (LPBYTE)(aHookInfo[nHookIdx].lpProcToHook);
      if ((dwFlags & NKTHOOKLIB_DontSkipInitialJumps) != 0)
      {
        lpHookEntry->lpOrigProc = lpHookEntry->SkipJumpInstructions(lpHookEntry->lpOrigProc);
        if (lpHookEntry->lpOrigProc == NULL)
        {
          dwOsErr = ERROR_ACCESS_DENIED;
          continue;
        }
      }
      lpHookEntry->lpNewProc = (LPBYTE)(aHookInfo[nHookIdx].lpNewProcAddr);
      //read original stub and create new one
      dwOsErr = lpHookEntry->CreateStub(int_data->sOptions.bOutputDebug,
                                        ((dwFlags & NKTHOOKLIB_DontSkipInitialJumps) == 0) ? TRUE : FALSE);
      if (dwOsErr != NO_ERROR)
        continue;
      //calculate inject code size and offset to data
      switch (cProcEntry->GetPlatform())
      {
        case NKT_HK_PROCESS_PLATFORM_X86:
          lpHookEntry->nInjCodeAndDataSize = 0x2A + lpHookEntry->nNewStubSize;
          break;
#if defined _M_X64
        case NKT_HK_PROCESS_PLATFORM_AMDX64:
          lpHookEntry->nInjCodeAndDataSize = 0x41 + lpHookEntry->nNewStubSize;
          break;
#endif //_M_X64
      }
      //allocate memory for inject code in target process
      _ASSERT(lpHookEntry->nInjCodeAndDataSize < NKTHOOKLIB_PROCESS_MEMBLOCK_SIZE);
      lpHookEntry->lpInjCodeAndData = cProcEntry->AllocateStub(lpHookEntry->lpOrigProc);
      if (lpHookEntry->lpInjCodeAndData == NULL)
      {
        dwOsErr = ERROR_NOT_ENOUGH_MEMORY;
        continue;
      }
      //setup code
      switch (cProcEntry->GetPlatform())
      {
        case NKT_HK_PROCESS_PLATFORM_X86:
          memset(aNewCode, 0x00, 8);                                               //flags location
          memset(aNewCode+0x08, 0x90, 8);                                          //NOPs for hotpatching double hooks
          aNewCode[0x10] = 0x50;                                                   //push  eax
          aNewCode[0x11] = 0xB8;                                                   //mov   eax, ADDR lpInjCode
          NktHooLib::WriteUnalignedULong(aNewCode+0x12, (ULONG)(lpHookEntry->lpInjCodeAndData));
          aNewCode[0x16] = 0xF7;                                                   //test  dword ptr [eax], 00000101h
          aNewCode[0x17] = 0x00;
          NktHooLib::WriteUnalignedULong(aNewCode+0x18, 0x00000101);
          aNewCode[0x1C] = 0x75;                                                   //jne   @@1 ;if disabled/uninst
          aNewCode[0x1D] = 0x06;
          aNewCode[0x1E] = 0x58;                                                   //pop   eax
          aNewCode[0x1F] = 0xE9;                                                   //jmp   hooked proc
          NktHooLib::WriteUnalignedULong(aNewCode+0x20, (ULONG)(lpHookEntry->lpNewProc) -
                                         (ULONG)(lpHookEntry->lpInjCodeAndData) - 0x24);
          aNewCode[0x24] = 0x58;                                                   //@@1: pop   eax
          lpHookEntry->lpCall2Orig = lpHookEntry->lpInjCodeAndData + 0x25;
          memcpy(aNewCode+0x25, lpHookEntry->aNewStub, lpHookEntry->nNewStubSize); //new stub
          aNewCode[0x25+lpHookEntry->nNewStubSize] = 0xE9;                         //jmp original proc after stub
          NktHooLib::WriteUnalignedULong(aNewCode+0x26+lpHookEntry->nNewStubSize,
                                         (ULONG)(lpHookEntry->lpOrigProc) + (ULONG)(lpHookEntry->nOriginalStubSize) -
                                         (ULONG)(lpHookEntry->lpInjCodeAndData+0x2A+lpHookEntry->nNewStubSize));
          break;

#if defined _M_X64
        case NKT_HK_PROCESS_PLATFORM_AMDX64:
          memset(aNewCode, 0x00, 8);                                               //flags location
          memset(aNewCode+0x08, 0x90, 8);                                          //NOPs for hotpatching double hooks
          aNewCode[0x10] = 0x50;                                                   //push  rax
          aNewCode[0x11] = 0x48;                                                   //mov   rax, ADDR lpInjCode
          aNewCode[0x12] = 0xB8;
          NktHooLib::WriteUnalignedULongLong(aNewCode+0x13, (ULONGLONG)(lpHookEntry->lpInjCodeAndData));
          aNewCode[0x1B] = 0xF7;                                                   //test  dword ptr [rax], 00000101h
          aNewCode[0x1C] = 0x00;
          NktHooLib::WriteUnalignedULong(aNewCode+0x1D, 0x00000101);
          aNewCode[0x21] = 0x75;                                                   //jne   @@1 ;if disabled/uninst
          aNewCode[0x22] = 0x0F;
          aNewCode[0x23] = 0x58;                                                   //pop   rax
          aNewCode[0x24] = 0xFF;                                                   //jmp   hooked proc
          aNewCode[0x25] = 0x25;
          NktHooLib::WriteUnalignedULong(aNewCode+0x26, 0);
          NktHooLib::WriteUnalignedULongLong(aNewCode+0x2A, (ULONGLONG)(lpHookEntry->lpNewProc));
          aNewCode[0x32] = 0x58;                                                   //@@1: pop   rax
          lpHookEntry->lpCall2Orig = lpHookEntry->lpInjCodeAndData+0x33;
          memcpy(aNewCode+0x33, lpHookEntry->aNewStub, lpHookEntry->nNewStubSize); //new stub
          aNewCode[0x33+lpHookEntry->nNewStubSize] = 0xFF;                         //jmp original proc after stub
          aNewCode[0x34+lpHookEntry->nNewStubSize] = 0x25;
          NktHooLib::WriteUnalignedULong(aNewCode+0x35+lpHookEntry->nNewStubSize, 0);
          NktHooLib::WriteUnalignedULongLong(aNewCode+0x39+lpHookEntry->nNewStubSize,
                                             (ULONGLONG)(lpHookEntry->lpOrigProc + lpHookEntry->nOriginalStubSize));
          break;
#endif //_M_X64
      }
      if (NktHooLib::ntApi_WriteMem(cProcEntry->GetHandle(), lpHookEntry->lpInjCodeAndData, aNewCode,
                                    lpHookEntry->nInjCodeAndDataSize) == FALSE)
      {
        dwOsErr = ERROR_ACCESS_DENIED;
        continue;
      }
      //replace original proc with a jump
      dw = (DWORD)(lpHookEntry->lpInjCodeAndData+8) - (DWORD)(lpHookEntry->lpOrigProc) - 5;
      lpHookEntry->aJumpStub[0] = 0xE9; //JMP
      lpHookEntry->aJumpStub[1] = (BYTE)( dw        & 0xFF);
      lpHookEntry->aJumpStub[2] = (BYTE)((dw >>  8) & 0xFF);
      lpHookEntry->aJumpStub[3] = (BYTE)((dw >> 16) & 0xFF);
      lpHookEntry->aJumpStub[4] = (BYTE)((dw >> 24) & 0xFF);
      //set id
#if defined _M_IX86
      lpHookEntry->nId = (SIZE_T)lpHookEntry ^ 0x34B68363UL; //odd number to avoid result of zero
#elif defined _M_X64
      lpHookEntry->nId = (SIZE_T)lpHookEntry ^ 0x34B68364A3CE19F3ui64; //odd number to avoid result of zero
#endif
      //done
      aHookInfo[nHookIdx].nHookId = lpHookEntry->nId;
      aHookInfo[nHookIdx].lpCallOriginal = lpHookEntry->lpCall2Orig;
    }
    //hook new items
    if (dwOsErr == NO_ERROR)
    {
      NktHooLib::CNktThreadSuspend::CAutoResume cAutoResume(&(int_data->cThreadSuspender));
      NktHooLib::CNktThreadSuspend::IP_RANGE sIpRanges[MAX_SUSPEND_IPRANGES];
      SIZE_T k, k2, nThisRoundSuspCount;
      HOOK_INFO sHooks[64];
      DWORD dw;

      for (nHookIdx=nThisRoundSuspCount=0; nHookIdx<nCount && dwOsErr==NO_ERROR; )
      {
        if (nThisRoundSuspCount == 0)
        {
          //suspend threads
          nThisRoundSuspCount = (nCount-nHookIdx > MAX_SUSPEND_IPRANGES) ? MAX_SUSPEND_IPRANGES : (nCount-nHookIdx);
          for (k=0; k<nThisRoundSuspCount; k++)
          {
            sIpRanges[k].nStart = (SIZE_T)(lpNewEntriesList[nHookIdx+k]->lpOrigProc);
            sIpRanges[k].nEnd = sIpRanges[k].nStart + HOOKENG_JUMP_TO_HOOK_SIZE;
          }
          dwOsErr = NO_ERROR;
          if (int_data->sOptions.bSuspendThreads != FALSE)
            dwOsErr = int_data->cThreadSuspender.SuspendAll(cProcEntry->GetPid(), sIpRanges, nThisRoundSuspCount);
          if (dwOsErr != NO_ERROR)
          {
err_uninstall_and_destroy:
            for (nHookIdx=k2=0; nHookIdx<nCount; nHookIdx++)
            {
              if (lpNewEntriesList[nHookIdx]->nInstalledCode != 0)
              {
                sHooks[k2++].nHookId = lpNewEntriesList[nHookIdx]->nId;
                if (k2 >= X_ARRAYLEN(sHooks))
                {
                  Unhook(sHooks, k2);
                  k2 = 0;
                }
              }
            }
            if (k2 > 0)
              Unhook(sHooks, k2);
            continue;
          }
        }
        for (k=0; k<nThisRoundSuspCount; k++)
        {
          //replace each entry point
          dw = 0;
          if (::VirtualProtectEx(cProcEntry->GetHandle(), lpNewEntriesList[nHookIdx+k]->lpOrigProc,
                                 HOOKENG_JUMP_TO_HOOK_SIZE, PAGE_EXECUTE_READWRITE, &dw) == FALSE &&
              ::VirtualProtectEx(cProcEntry->GetHandle(), lpNewEntriesList[nHookIdx+k]->lpOrigProc,
                                 HOOKENG_JUMP_TO_HOOK_SIZE, PAGE_EXECUTE_WRITECOPY, &dw) == FALSE)
          {
            dwOsErr = ::GetLastError();
            int_data->cThreadSuspender.ResumeAll();
            goto err_uninstall_and_destroy;
          }
          if (NktHooLib::ntApi_WriteMem(cProcEntry->GetHandle(), lpNewEntriesList[nHookIdx+k]->lpOrigProc,
                                        lpNewEntriesList[nHookIdx+k]->aJumpStub, HOOKENG_JUMP_TO_HOOK_SIZE) == FALSE)
          {
            ::VirtualProtectEx(cProcEntry->GetHandle(), lpNewEntriesList[nHookIdx+k]->lpOrigProc,
                               HOOKENG_JUMP_TO_HOOK_SIZE, dw, &dw);
            dwOsErr = ERROR_ACCESS_DENIED;
            int_data->cThreadSuspender.ResumeAll();
            goto err_uninstall_and_destroy;
          }
          ::VirtualProtectEx(cProcEntry->GetHandle(), lpNewEntriesList[nHookIdx+k]->lpOrigProc,
                             HOOKENG_JUMP_TO_HOOK_SIZE, dw, &dw);
          //flush instruction cache
          ::FlushInstructionCache(cProcEntry->GetHandle(), lpNewEntriesList[nHookIdx+k]->lpOrigProc, 32);
          //mark as installed
          lpNewEntriesList[nHookIdx+k]->nInstalledCode = 1;
        }
        //advance count
        nHookIdx += nThisRoundSuspCount;
        //check if we can proceed with the next hook with this
        nThisRoundSuspCount = 0;
        for (k=nHookIdx; k<nCount; k++)
        {
          k2 = (SIZE_T)(lpNewEntriesList[k]->lpOrigProc);
          if (int_data->cThreadSuspender.CheckIfThreadIsInRange(k2, k2+HOOKENG_JUMP_TO_HOOK_SIZE) == FALSE)
            break;
          nThisRoundSuspCount++;
        }
        if (nThisRoundSuspCount == 0)
        {
          //resume threads
          int_data->cThreadSuspender.ResumeAll();
        }
      }
    }
    //done... move to the final list or delete on error
    if (dwOsErr == NO_ERROR)
    {
      for (nHookIdx=0; nHookIdx<nCount; nHookIdx++)
      {
        lpNewEntriesList[nHookIdx]->dwFlags = dwFlags;
        int_data->cHooksList.PushTail(lpNewEntriesList[nHookIdx]);
      }
    }
    else
    {
      for (nHookIdx=0; nHookIdx<nCount; nHookIdx++)
        delete lpNewEntriesList[nHookIdx];
    }
    if (lpNewEntriesList != NULL)
      free(lpNewEntriesList);
  }
  else
  {
    dwOsErr = ERROR_NOT_ENOUGH_MEMORY;
  }
  return dwOsErr;
}

DWORD CNktHookLib::RemoteHook(__out SIZE_T *lpnHookId, __out LPVOID *lplpCallOriginal, __in HANDLE hProcess,
                              __in LPVOID lpProcToHook, __in LPVOID lpNewProcAddr, __in DWORD dwFlags)
{
  HOOK_INFO sHook;
  DWORD dwOsErr;

  if (lpnHookId != NULL)
    *lpnHookId = 0;
  if (lplpCallOriginal != NULL)
    *lplpCallOriginal = NULL;
  if (lpnHookId == NULL || lplpCallOriginal == NULL || hProcess == NULL)
    return ERROR_INVALID_PARAMETER;
  sHook.lpProcToHook = lpProcToHook;
  sHook.lpNewProcAddr = lpNewProcAddr;
  dwOsErr = RemoteHook(&sHook, 1, hProcess, dwFlags);
  if (dwOsErr == NO_ERROR)
  {
    *lpnHookId = sHook.nHookId;
    *lplpCallOriginal = sHook.lpCallOriginal;
  }
  return dwOsErr;
}


DWORD CNktHookLib::RemoteHook(__inout HOOK_INFO aHookInfo[], __in SIZE_T nCount, __in HANDLE hProcess,
                              __in DWORD dwFlags)
{
  DWORD dwPid;

  dwPid = GetProcessIdFromHandle(hProcess);
  if (dwPid == 0)
  {
    for (SIZE_T i=0; i<nCount; i++)
    {
      aHookInfo[i].nHookId = 0;
      aHookInfo[i].lpCallOriginal = NULL;
    }
    return ERROR_INVALID_PARAMETER;
  }
  return RemoteHook(aHookInfo, nCount, dwPid, dwFlags);
}

DWORD CNktHookLib::Unhook(__in SIZE_T nHookId)
{
  HOOK_INFO sHook;

  sHook.nHookId = nHookId;
  return Unhook(&sHook, 1);
}

DWORD CNktHookLib::Unhook(__in HOOK_INFO aHookInfo[], __in SIZE_T nCount)
{
  NktHooLib::TNktLnkLst<NktHooLib::CHookEntry> cToDeleteList;
  NktHooLib::CHookEntry *lpHookEntry;

  if (aHookInfo == NULL || nCount == 0)
    return ERROR_INVALID_PARAMETER;
  if (lpInternals != NULL)
  {
    NktHooLib::CNktAutoFastMutex cAutoLock(&(int_data->cMtx));
    NktHooLib::CNktThreadSuspend::CAutoResume cAutoResume(&(int_data->cThreadSuspender));
    NktHooLib::CNktThreadSuspend::IP_RANGE sIpRange[2];
    NktHooLib::TNktLnkLst<NktHooLib::CHookEntry>::Iterator it;
    BYTE aTempBuf[HOOKENG_JUMP_TO_HOOK_SIZE];
    SIZE_T nHookIdx, nIpRangesCount;
    DWORD dw, dwOsErr;
    BOOL bOk;

    for (nHookIdx=nIpRangesCount=0; nHookIdx<nCount; nHookIdx++)
    {
      for (lpHookEntry=it.Begin(int_data->cHooksList); lpHookEntry!=NULL; lpHookEntry=it.Next())
      {
        if (lpHookEntry->nId == aHookInfo[nHookIdx].nHookId)
          break;
      }
      if (lpHookEntry == NULL)
        continue; //hook not found
      //mark the hook as uninstalled
      if ((lpHookEntry->dwFlags & NKTHOOKLIB_DontRemoveOnUnhook) != 0)
      {
        bOk = FALSE;
      }
      else
      {
        if (lpHookEntry->cProcEntry != NULL)
        {
          BYTE nVal = 1;
          ntApi_WriteMem(lpHookEntry->cProcEntry, lpHookEntry->lpInjCodeAndData, &nVal, 1);
        }
        else
        {
          _InterlockedExchange((LONG volatile *)(lpHookEntry->lpInjCodeAndData), 1);
        }
        if (lpHookEntry->nInstalledCode != 3)
          lpHookEntry->nInstalledCode = 2;
        //suspend threads if needed
        dwOsErr = NO_ERROR;
        if (int_data->sOptions.bSuspendThreads != FALSE)
        {
          //set-up ranges
          sIpRange[0].nStart = (SIZE_T)(lpHookEntry->lpOrigProc);
          sIpRange[0].nEnd = sIpRange[0].nStart + 5;
          sIpRange[1].nStart = (SIZE_T)(lpHookEntry->lpInjCodeAndData);
          sIpRange[1].nEnd = sIpRange[1].nStart + lpHookEntry->nInjCodeAndDataSize;
          if (nIpRangesCount > 0)
          {
            //check if a previous thread suspension can be used for the current unhook item
            if (int_data->cThreadSuspender.CheckIfThreadIsInRange(sIpRange[0].nStart, sIpRange[0].nEnd) != FALSE ||
                int_data->cThreadSuspender.CheckIfThreadIsInRange(sIpRange[1].nStart, sIpRange[1].nEnd) != FALSE)
            {
              nIpRangesCount = 0;
              int_data->cThreadSuspender.ResumeAll(); //resume last
            }
          }
          //suspend threads
          if (nIpRangesCount == 0)
          {
            nIpRangesCount = X_ARRAYLEN(sIpRange);
            dwOsErr = int_data->cThreadSuspender.SuspendAll(lpHookEntry->cProcEntry->GetPid(), sIpRange, nIpRangesCount);
          }
        }
        //do unhook
        bOk = FALSE;
        if (dwOsErr == NO_ERROR)
        {
          dw = 0;
          if (::VirtualProtectEx(lpHookEntry->cProcEntry->GetHandle(), lpHookEntry->lpOrigProc,
                                 lpHookEntry->nOriginalStubSize, PAGE_EXECUTE_READWRITE, &dw) != FALSE ||
              ::VirtualProtectEx(lpHookEntry->cProcEntry->GetHandle(), lpHookEntry->lpOrigProc,
                                 lpHookEntry->nOriginalStubSize, PAGE_EXECUTE_WRITECOPY, &dw) != FALSE)
          {
            if (NktHooLib::ntApi_ReadMem(lpHookEntry->cProcEntry->GetHandle(), aTempBuf, lpHookEntry->lpOrigProc,
                                         HOOKENG_JUMP_TO_HOOK_SIZE) == HOOKENG_JUMP_TO_HOOK_SIZE &&
                memcmp(aTempBuf, lpHookEntry->aJumpStub, HOOKENG_JUMP_TO_HOOK_SIZE) == 0)
            {
              bOk = NktHooLib::ntApi_WriteMem(lpHookEntry->cProcEntry->GetHandle(), lpHookEntry->lpOrigProc,
                                              lpHookEntry->aOriginalStub, lpHookEntry->nOriginalStubSize);
            }
            ::VirtualProtectEx(lpHookEntry->cProcEntry->GetHandle(), lpHookEntry->lpOrigProc,
                               lpHookEntry->nOriginalStubSize, dw, &dw);
            ::FlushInstructionCache(lpHookEntry->cProcEntry->GetHandle(), lpHookEntry->lpOrigProc, 32);
          }
        }
      }
      //check result
      if (bOk == FALSE)
      {
        //if cannot release original blocks, mark them as uninstalled
        lpHookEntry->lpInjCodeAndData = NULL;
      }
      //delete entry
      int_data->cHooksList.Remove(lpHookEntry);
      cToDeleteList.PushTail(lpHookEntry);
    }
  }
  //delete when no threads are suspended to avoid deadlocks
  while ((lpHookEntry = cToDeleteList.PopHead()) != NULL)
    delete lpHookEntry;
  return NO_ERROR;
}

VOID CNktHookLib::UnhookProcess(__in DWORD dwPid)
{
  if (lpInternals != NULL)
  {
    NktHooLib::CNktAutoFastMutex cAutoLock(&(int_data->cMtx));
    NktHooLib::TNktLnkLst<NktHooLib::CHookEntry>::Iterator it;
    NktHooLib::CHookEntry *lpHookEntry;
    HOOK_INFO sHooks[256];
    SIZE_T nCount;

    if (dwPid == 0)
      dwPid = ::GetCurrentProcessId();
    do
    {
      nCount = 0;
      for (lpHookEntry=it.Begin(int_data->cHooksList); lpHookEntry!=NULL && nCount<X_ARRAYLEN(sHooks);
           lpHookEntry=it.Next())
      {
        if (lpHookEntry->cProcEntry->GetPid() == dwPid)
          sHooks[nCount++].nHookId = lpHookEntry->nId;
      }
      if (nCount > 0)
        Unhook(sHooks, nCount);
    }
    while (nCount > 0);
  }
  return;
}

VOID CNktHookLib::UnhookAll()
{
  if (lpInternals != NULL)
  {
    NktHooLib::CNktAutoFastMutex cAutoLock(&(int_data->cMtx));
    NktHooLib::TNktLnkLst<NktHooLib::CHookEntry>::Iterator it;
    NktHooLib::TNktLnkLst<NktHooLib::CHookEntry>::IteratorRev itRev;
    NktHooLib::CHookEntry *lpHookEntry;
    HOOK_INFO sHooks[256];
    SIZE_T nCount;

    //mark all hooks as uninstalled first
    for (lpHookEntry=it.Begin(int_data->cHooksList); lpHookEntry!=NULL; lpHookEntry=it.Next())
    {
      if (lpHookEntry->cProcEntry != NULL)
      {
        BYTE nVal = 1;
        ntApi_WriteMem(lpHookEntry->cProcEntry, lpHookEntry->lpInjCodeAndData, &nVal, 1);
      }
      else
      {
        _InterlockedExchange((LONG volatile *)(lpHookEntry->lpInjCodeAndData), 1);
      }
      lpHookEntry->nInstalledCode = 3;
    }
    //unhook in reverse order
    while (int_data->cHooksList.IsEmpty() == FALSE)
    {
      for (nCount=0,lpHookEntry=itRev.Begin(int_data->cHooksList); lpHookEntry!=NULL && nCount<X_ARRAYLEN(sHooks);
           lpHookEntry=itRev.Next())
        sHooks[nCount++].nHookId = lpHookEntry->nId;
      if (nCount > 0)
        Unhook(sHooks, nCount);
    }
  }
  return;
}

DWORD CNktHookLib::EnableHook(__in SIZE_T nHookId, __in BOOL bEnable)
{
  HOOK_INFO sHook;

  sHook.nHookId = nHookId;
  return EnableHook(&sHook, 1, bEnable);
}

DWORD CNktHookLib::EnableHook(__in HOOK_INFO aHookInfo[], __in SIZE_T nCount, __in BOOL bEnable)
{
  if (aHookInfo == NULL || nCount == 0)
    return ERROR_INVALID_PARAMETER;
  if (lpInternals == NULL)
    return ERROR_NOT_ENOUGH_MEMORY;
  {
    NktHooLib::CNktAutoFastMutex cAutoLock(&(int_data->cMtx));
    NktHooLib::TNktLnkLst<NktHooLib::CHookEntry>::Iterator it;
    NktHooLib::CHookEntry *lpHookEntry;
    SIZE_T nHookIdx;

    //write flags
    for (nHookIdx=0; nHookIdx<nCount; nHookIdx++)
    {
      for (lpHookEntry=it.Begin(int_data->cHooksList); lpHookEntry!=NULL; lpHookEntry=it.Next())
      {
        if (lpHookEntry->nId == aHookInfo[nHookIdx].nHookId)
        {
          if (lpHookEntry->cProcEntry != NULL)
          {
            BYTE nVal = (bEnable != FALSE) ? 0 : 1;
            ntApi_WriteMem(lpHookEntry->cProcEntry, lpHookEntry->lpInjCodeAndData+1, &nVal, 1);
          }
          else
          {
            _InterlockedExchange((LONG volatile *)(lpHookEntry->lpInjCodeAndData+1), (bEnable != FALSE) ? 0 : 1);
          }
          break;
        }
      }
    }
  }
  return NO_ERROR;
}

DWORD CNktHookLib::SetSuspendThreadsWhileHooking(__in BOOL bEnable)
{
  if (lpInternals == NULL)
    return ERROR_NOT_ENOUGH_MEMORY;
  {
    NktHooLib::CNktAutoFastMutex cAutoLock(&(int_data->cMtx));

    int_data->sOptions.bSuspendThreads = bEnable;
  }
  return NO_ERROR;
}

BOOL CNktHookLib::GetSuspendThreadsWhileHooking()
{
  BOOL b;

  b = TRUE;
  if (lpInternals != NULL)
  {
    NktHooLib::CNktAutoFastMutex cAutoLock(&(int_data->cMtx));

    b = int_data->sOptions.bSuspendThreads;
  }
  return b;
}

DWORD CNktHookLib::SetEnableDebugOutput(__in BOOL bEnable)
{
  if (lpInternals == NULL)
    return ERROR_NOT_ENOUGH_MEMORY;
  {
    NktHooLib::CNktAutoFastMutex cAutoLock(&(int_data->cMtx));

    int_data->sOptions.bOutputDebug = bEnable;
  }
  return NO_ERROR;
}

BOOL CNktHookLib::GetEnableDebugOutput()
{
  BOOL b;

  b = TRUE;
  if (lpInternals != NULL)
  {
    NktHooLib::CNktAutoFastMutex cAutoLock(&(int_data->cMtx));

    b = int_data->sOptions.bOutputDebug;
  }
  return b;
}

//-----------------------------------------------------------

static DWORD GetProcessIdFromHandle(__in HANDLE hProc)
{
  PROCESS_BASIC_INFORMATION sPbi;

  if (hProc != NULL)
  {
    if (hProc == ::GetCurrentProcess())
      return ::GetCurrentProcessId();
    memset(&sPbi, 0, sizeof(sPbi));
    if (NktHooLib::ntApi_NtQueryInformationProcess(hProc, NktHooLib::MyProcessBasicInformation, &sPbi,
                                                   sizeof(sPbi), NULL) >= 0)
      return (DWORD)sPbi.UniqueProcessId;
  }
  return 0;
}
