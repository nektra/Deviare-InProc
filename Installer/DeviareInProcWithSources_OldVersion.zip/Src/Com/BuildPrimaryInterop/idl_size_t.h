#ifdef _WIN64
  typedef void* my_ssize_t;
  typedef void* my_size_t;
#else //_WIN64
  typedef void* my_ssize_t;
  typedef void* my_size_t;
#endif //_WIN64