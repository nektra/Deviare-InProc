﻿/*
 * Copyright (C) 2010-2014 Nektra S.A., Buenos Aires, Argentina.
 * All rights reserved.
 *
 **/

#include "StdAfx.h"
#include "resource.h"
#ifdef _WIN64
  #include "DeviareLiteCOM_i64.h"
#else //_WIN64
  #include "DeviareLiteCOM_i.h"
#endif //_WIN64
#include "dllmain.h"
#include "dlldatax.h"

//-----------------------------------------------------------

CDeviareLiteCOMModule _AtlModule;
HINSTANCE hDllInst;

//-----------------------------------------------------------

// DLL Entry Point
extern "C" BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
  if (dwReason == DLL_PROCESS_ATTACH)
    hDllInst = hInstance;
#ifdef _MERGE_PROXYSTUB
  if (!PrxDllMain(hInstance, dwReason, lpReserved))
    return FALSE;
#endif
  return _AtlModule.DllMain(dwReason, lpReserved); 
}
