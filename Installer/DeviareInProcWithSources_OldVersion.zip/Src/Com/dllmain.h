﻿/*
 * Copyright (C) 2010-2014 Nektra S.A., Buenos Aires, Argentina.
 * All rights reserved.
 *
 **/

#pragma once

#ifdef _WIN64
  #include "DeviareLiteCOM_i64.h"
#else //_WIN64
  #include "DeviareLiteCOM_i.h"
#endif //_WIN64

//-----------------------------------------------------------

class CDeviareLiteCOMModule : public CAtlDllModuleT<CDeviareLiteCOMModule>
{
public :
  DECLARE_LIBID(LIBID_DeviareLite)
#ifdef _WIN64
  DECLARE_REGISTRY_APPID_RESOURCEID(IDR_DEVIARELITECOM64, "{7F65AF61-32C2-4f4e-9B91-7C32910503FD}")
#else //_WIN64
  DECLARE_REGISTRY_APPID_RESOURCEID(IDR_DEVIARELITECOM, "{7F65AF62-32C2-4f4e-9B91-7C32910503FD}")
#endif //_WIN64
};

//-----------------------------------------------------------

extern class CDeviareLiteCOMModule _AtlModule;
